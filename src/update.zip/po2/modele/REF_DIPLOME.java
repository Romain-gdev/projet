package po2.modele;

/**
 * Enum�ration d�finissant les dipl�mes de r�f�rence
 */
public enum REF_DIPLOME {

    BTS_SIO_SLAM("BTS SIO SLAM"),
    BTS_SN_IR("BTS SN IR"),
    DUT_INFO("DUT informatique"),
    LICENCE_INFO("Licence informatique");

    private final String str;

    REF_DIPLOME(String str) {
        this.str = str;
    }

    /**
     * @return une cha�ne de caract�res repr�sentant le diplome de ref�rence
     */
    @Override
    public String toString() {
        return str;
    }
}
