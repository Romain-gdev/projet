package po2.modele;

/**
 * Enum�ration definissant les s�ries du bac prises en compte
 */
public enum SERIE {
    S,
    L,
    ES,
    STI2D,
    STMG
}
